package com.example.demo.Exception;

public class EmployeException extends RuntimeException {
    
	String message;

	public EmployeException(String message2) {
		// TODO Auto-generated constructor stub
	}

	public static EmployeException create(final String message) {
		
		return new EmployeException(message);
	}
}
