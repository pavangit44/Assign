package com.example.demo.service;


import com.example.demo.Entity.Employee;
import com.example.demo.VO.EmployeVO;

public interface EmployeeService {

	Employee saveEmployeeDeatils(EmployeVO details) throws Exception;
	EmployeVO getEmployeeDetails(long employeeid) throws Exception;
}
