package com.example.demo.serviceimpl;

import java.util.Objects;

import org.apache.catalina.startup.ClassLoaderFactory.Repository;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;


import com.example.demo.Exception.EmployeException;
import com.example.demo.Repo.EmployeeRepository;
import com.example.demo.VO.EmployeVO;

import com.example.demo.Entity.Employee;
import com.example.demo.service.EmployeeService;

public class EmployeeServiceImpl implements EmployeeService {
    
	@Autowired
	EmployeeRepository Repo;
	
	@Autowired
	Employee emp ;
	
	@Autowired
	ModelMapper modelmap;

	
	@Override
	public Employee saveEmployeeDeatils(EmployeVO details) throws Exception {
		
		if(Objects.nonNull(details)) {
			validateEmployeVO(details);
			
			emp.setEmployeeId(details.getEmployeeId());
			emp.setFirstName(details.getFirstName());
			emp.setLastName(details.getLastName());
			emp.setEmail(details.getEmail());
			emp.setDOJ(details.getDOJ());
			emp.setPhoneNumbers(details.getPhoneNumbers());
			emp.setSalary(details.getSalary());
			
		
			// we can use modelmapper
			//Employee em=modelmap.map(details,Employee.class);
			
			
			
			Repo.save(emp);
		}
		return emp;
	}
	
	public void validateEmployeVO(EmployeVO details) {
		
		if(Objects.isNull(details.getEmployeeId())) {
			
			throw EmployeException.create("EmployeeId cannot be Blank");
		}
		
		if (Objects.isNull(details.getFirstName())) {

			throw EmployeException.create("FirstName cannot be Blank");
		}

		if (Objects.isNull(details.getLastName())) {

			throw EmployeException.create("LastName cannot be Blank");
		}

		if (Objects.isNull(details.getEmail())) {

			throw EmployeException.create("Email cannot be Blank");
		}

		if (Objects.isNull(details.getDOJ())) {

			throw EmployeException.create("Date Of Joing cannot be Blank");
		}

		if (details.getPhoneNumbers().isEmpty()) {

			throw EmployeException.create("PhoneNumbers cannot be Empty");
		}

		if (Objects.isNull(details.getSalary())) {

			throw EmployeException.create("Salary cannot be Blank");
		}
	}

	@Override
	public EmployeVO getEmployeeDetails(long employeeid) throws Exception {
		
		if(Objects.nonNull(employeeid)) {
			
		 Employee employee= Repo.findById(employeeid).orElse(null);
				 
				 
		 
		 if(Objects.nonNull(employee)) {
			 
			 EmployeVO details = new EmployeVO();
			 
			 details.setEmployeeId(employee.getEmployeeId());
			 details.setFirstName(employee.getFirstName());
			 details.setLastName(employee.getLastName());
			 details.setEmail(employee.getEmail());
			 details.setDOJ(employee.getDOJ());
			 details.setPhoneNumbers(employee.getPhoneNumbers());
			 details.setSalary(employee.getSalary());
			 return details;

		 }
		}
		return null;
	}

}
