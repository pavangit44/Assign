package com.example.demo.service;



import com.example.demo.VO.TaxResponseVO;

public interface EmployeeTaxService {

	public TaxResponseVO calculateTax(long employeeid);
}
