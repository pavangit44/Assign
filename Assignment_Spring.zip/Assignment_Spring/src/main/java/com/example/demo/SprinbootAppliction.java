package com.example.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SprinbootAppliction {

	public static void main(String[] args) {
		SpringApplication.run(SprinbootAppliction.class, args);
	}

}
